# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.
#

version_info = (0, 17, 4)

__version__ = '%s.%s.%s' % (version_info[0], version_info[1], version_info[2])

EXTENSION_VERSION = '^0.17'
